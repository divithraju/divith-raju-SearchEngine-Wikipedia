python myWikiIndexer.py $1 $2
python k-way-merge.py